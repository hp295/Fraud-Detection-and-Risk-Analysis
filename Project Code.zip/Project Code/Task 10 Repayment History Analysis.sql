-- Task 10: Rank loans by repayment consistency
SELECT 
    loan_id,
    COUNT(*) AS total_emi_paid,
    RANK() OVER (ORDER BY COUNT(*) DESC) AS repayment_rank
FROM 
    transaction_table
WHERE 
    transaction_type = 'EMI Payment'
GROUP BY 
    loan_id;
