-- Analyze the types of loan purposes customers borrow for (e.g., home, education, business) and determine which categories are most popular and profitable.

-- Task 2: Analyze popular and profitable loan purposes
SELECT 
    loan_purpose,
    COUNT(*) AS total_loans,
    SUM(loan_amount) AS total_amount
FROM 
    loan_table
GROUP BY 
    loan_purpose
ORDER BY 
    total_amount DESC;
