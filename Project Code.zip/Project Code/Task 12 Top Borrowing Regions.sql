-- Task 12: Identify top loan disbursement regions
SELECT 
    TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(address, ',', 2),
                ',',
                - 1)) AS city,
                 TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(address, ',', -2), ' ', 1)) AS state,
    COUNT(l.loan_id) AS total_loans,
    SUM(l.loan_amount) AS total_loan_amount
FROM
    loan_table l
        JOIN
    customer_table c ON l.customer_id = c.customer_id
GROUP BY city,state
ORDER BY total_loan_amount DESC
