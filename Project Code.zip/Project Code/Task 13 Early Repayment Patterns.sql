-- Assume a loan is expected to last 12 months
-- Loans closed in less than 12 months are early repayments
SELECT 
    t.loan_id,
    MIN(STR_TO_DATE(t.transaction_date, '%m/%d/%Y %H:%i')) AS first_payment_date,
    MAX(STR_TO_DATE(t.transaction_date, '%m/%d/%Y %H:%i')) AS last_payment_date,
    TIMESTAMPDIFF(MONTH,
        MIN(STR_TO_DATE(t.transaction_date, '%m/%d/%Y %H:%i')),
        MAX(STR_TO_DATE(t.transaction_date, '%m/%d/%Y %H:%i'))) AS active_duration_months,
    l.loan_amount,
    CASE
        WHEN
            TIMESTAMPDIFF(MONTH,
                MIN(STR_TO_DATE(t.transaction_date, '%m/%d/%Y %H:%i')),
                MAX(STR_TO_DATE(t.transaction_date, '%m/%d/%Y %H:%i'))) < 12
        THEN
            'Early Repaid'
        ELSE 'Normal'
    END AS repayment_status
FROM
    transaction_table t
        JOIN
    loan_table l ON t.loan_id = l.loan_id
WHERE
    t.transaction_type IN ('EMI Payment' , 'Prepayment')
GROUP BY t.loan_id , l.loan_amount
HAVING repayment_status = 'Early Repaid';
