-- Task 7: Loans with frequent On-time EMI payments
SELECT 
    loan_id,
    COUNT(*) AS total_emi_payments,
    SUM(CASE 
        WHEN remarks = 'On-time payment.' AND status = 'Successful' THEN 1 
        ELSE 0 
    END) AS on_time_success_count
FROM 
    transaction_table
WHERE 
    transaction_type = 'EMI Payment'
GROUP BY 
    loan_id
HAVING 
    on_time_success_count >0 ; -- or your threshold for "frequent"
