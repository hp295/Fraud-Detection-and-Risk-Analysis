-- Task 8: Analyze loan behavior across age groups
SELECT 
    CASE 
        WHEN age < 25 THEN 'Under 25'
        WHEN age BETWEEN 25 AND 35 THEN '25-35'
        WHEN age BETWEEN 36 AND 50 THEN '36-50'
        ELSE '50+'
    END AS age_group,
    COUNT(l.loan_id) AS total_loans,
    AVG(l.loan_amount) AS avg_loan_amount
FROM 
    customer_table c
JOIN 
    loan_table l ON c.customer_id = l.customer_id
GROUP BY 
    age_group;
