-- Task 6: Customers associated for over 5 years
SELECT 
    c.customer_id,
    c.name,
    c.customer_since,
    COUNT(l.loan_id) AS total_loans
FROM 
    customer_table c
LEFT JOIN 
    loan_table l ON c.customer_id = l.customer_id
WHERE 
    c.customer_since <= DATE_SUB(CURDATE(), INTERVAL 5 YEAR)
GROUP BY 
    c.customer_id;
