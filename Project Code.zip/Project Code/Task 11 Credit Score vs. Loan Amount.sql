-- Task 11: Compare loan amounts by credit score bands
SELECT 
    CASE 
        WHEN credit_score < 600 THEN 'Poor (<600)'
        WHEN credit_score BETWEEN 600 AND 700 THEN 'Average (600-700)'
        ELSE 'Good (>700)'
    END AS score_band,
    AVG(loan_amount) AS avg_loan_amount
FROM 
    customer_table c
JOIN 
    loan_table l ON c.customer_id = l.customer_id
GROUP BY 
    score_band;
