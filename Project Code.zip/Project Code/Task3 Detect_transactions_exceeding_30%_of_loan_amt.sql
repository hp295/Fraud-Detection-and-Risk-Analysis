-- High-Value Transactions
-- Task: Detect transactions that exceed 30% of their related loan amount. These anomalies could suggest unusual activities worth investigating.

-- Task 3: Detect transactions exceeding 30% of loan amount
SELECT 
    t.transaction_id,
    t.loan_id,
    t.transaction_amount,
    l.loan_amount
FROM 
    transaction_table t
JOIN 
    loan_table l ON t.loan_id = l.loan_id
WHERE 
    t.transaction_amount > 0.3 * l.loan_amount;
