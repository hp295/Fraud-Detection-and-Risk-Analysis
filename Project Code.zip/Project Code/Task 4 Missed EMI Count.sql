-- Task 4: Count missed EMI payments per loan
SELECT 
    loan_id,
    COUNT(*) AS missed_emi_count
FROM 
    transaction_table
WHERE 
    transaction_type = 'Missed EMI'
GROUP BY 
    loan_id
HAVING 
    missed_emi_count > 2; -- threshold adjustable
