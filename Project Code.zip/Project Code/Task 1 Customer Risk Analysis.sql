-- Task 1: Customer Risk Analysis
-- Identify customers with poor credit scores who are associated with loans marked as high default risk. 
-- Your goal is to isolate potentially risky borrowers that the bank should monitor or intervene with.	

SELECT 
    c.customer_id,
    c.name,
    c.credit_score,
    l.loan_id,
    l.default_risk
FROM 
    customer_table c
JOIN 
    loan_table l ON c.customer_id = l.customer_id
WHERE 
    c.credit_score < 600 AND l.default_risk = 'High';
