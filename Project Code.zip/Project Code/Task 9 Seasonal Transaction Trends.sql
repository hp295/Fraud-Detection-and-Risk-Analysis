-- Task 9: Monthly transaction trends
SELECT 
	YEAR(STR_TO_DATE(transaction_date, '%m/%d/%Y %H:%i')) AS year,
    MONTH(STR_TO_DATE(transaction_date, '%m/%d/%Y %H:%i')) AS month,
    COUNT(*) AS total_transactions,
    SUM(transaction_amount) AS total_amount
FROM 
    transaction_table
GROUP BY 
    year, month
ORDER BY 
    year, month;
