-- Task 5: Evaluate loan distribution by region
SELECT 
    c.address,
       TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(address, ',', 2),
                ',',
                - 1)) AS city,
                   TRIM(SUBSTRING_INDEX(address, ' ', -1)) AS zip_code,
                    TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(address, ',', -2), ' ', 1)) AS state,
    COUNT(l.loan_id) AS total_loans,
    SUM(l.loan_amount) AS total_disbursed
FROM 
    loan_table l
JOIN 
    customer_table c ON l.customer_id = c.customer_id
GROUP BY 
    c.address, city,zip_code,state
ORDER BY 
    total_disbursed DESC;
